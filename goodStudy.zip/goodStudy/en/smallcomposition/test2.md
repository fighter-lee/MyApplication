Suppose you have to cancel your travel plan and will not be able to visit Professor Smith. Write him an
email to
1) apologize and explain the situation, and
2) suggest a future meeting.
You should write about 100 words neatly on the ANSWER SHEET.
Do not use your own name at the end of the email. Use “Li Ming” instead (10 points)

Dear Professor Smith:
    


Your sincerely
LiMing