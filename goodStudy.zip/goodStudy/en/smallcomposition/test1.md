![avatar](../pic/small2019.png)
　　Suppose Professor Smith asked you to plan a debate on the theme of traffic. Write him an email to

　　1） Suggest a specific topic with your reasons, and

　　2） Tell him about your arrangements.

　　You should write about 100 words on the ANSWER SHETE.

　　Do not use your one name. Use “Li Ming” instead. （10 points）

![](http://www.offcn.com/dl/2018/1226/20181226093755726.jpg)

Dear professor Smith,
    I am writing this letter to you to present my suggestion for the theme of city traffic and tell you about my arrangements.
    As far as I am concerned, it is appropriate for the city traffic to set the topic of Public Car. In the first place, with 
the rapid growth of population, public bus plays an increasingly important role in public traffic. Most of us need to take 
public bus to work and travel. In the second place, private car has been expanding significantly in recent years, thus exerts 
a negative impact on city environment, correspondingly, public car is good to our environment. In addition, it is wise to arrange 
the debate in the next weekends.
    My highly appreciation goes for your precious time from your busy schedule spent on this letter. Your favorable response at 
your earliest convenience would be highly appreciated.  
                                                                                yours sincerely.  
                                                                                        Li Ming