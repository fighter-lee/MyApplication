    As can be seen from the pie chart/table chart/column chart/line graph above, remarkably different of trends of ___ are vividly demonstrated. 
There was a striking/gradual growth/decline in ___, from __ in __ to __ in __. At the meanwhile, ____ has undergone a significant/slight 
growth/decline during the same period, from __ to __. As for ____, it almost remained stable at/under 10%.

    As can be seen from the pie chart/table chart/column chart/line graph above, major differences are detected in terms of the proportion of ____ 
among distinct groups. Based on the statistics of the chart, ___ occupy the dominant position, accounting for __. ____ take the percentage of ____, 
ranging for the distant/close second. While ____ comprise the relatively small proportion of ___, coming to the last one. 

    Obviously, a variety of complicated factors contribute to the phenomenon, with the following ones being the foremost. 
In the first place, as for ___, it is a much strong desire rooted in their nature to _____, correspondingly, ____ enable them to ___ much easily. 
In other words, ___ can precisely meet the needs of ___, which can partly account for the phenomenon shown in the chart. 
In the second place, ___ has been expanding significantly in recent years, thus providing people ____(a wide variety of product in a reasonable price). 
Obviously, ___(the manufacturers's) rapid development also exerts a positive impact on people's ____.
    
    Taking the aspects of both the ___ and the whole ___ into account, we may make a reasonable prediction. It can be inferred that 
____ is projected to show an upward trend owing to _____(customers' increasing demands) and ____(the improvement of industry/manufacturers/social welfare/technology/residents' living standard/ )