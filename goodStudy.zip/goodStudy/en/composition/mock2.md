![avatar](../pic/mock2.png)

the amounts of people who do physical exercise in gym

   As can be seen from the line graph above, remarkably similar trends of the amounts of gyms and people who do physical exercise in gym are vividly demonstrated. 
There was a striking growth in the amounts of people who do physical exercise in gym, from 1 million in 2015 to 2 million 2017. At the meanwhile, the amount 
of gyms has undergone significant growth during the same period, from 600 to 850.
   Obviously, a variety of complicated factors contribute to the phenomenon, with the following ones being the foremost. In the first place, as for residents, it is 
a much strong desire rooted in their nature to own a health body, correspondingly, doing physical exercise in gyms enables them to keep healthy much easily. 
In other words, Doing physical exercise can precisely meet the needs of people, which can partly account for the phenomenon shown in the chart. For the second 
place, the gym industry has been expanding significantly in recent years, thus providing people with a wide variety of gyms in a reasonable price. Obviously, 
the gym industry's rapid development also exerts a positive impact on people's choosing to do exercise in gyms.
   Taking the aspects of residents and the whole gym industry into account, we may make a reasonable prediction. It can be inferred that the amount of people who 
do exercise in gyms is projected to show an upward trend owing people's increasing demand of healthy and the development of the gym industry.