表格table / 饼状图pie chart /条状图 bar chart / 线状图 line graph/ 柱形图 column chart

百万：million  十亿：billion 

人口：population
比例：proportion

negative
it is appropriate/advisable for sb to do sth.
it is wise to do
In addition
in conclusion
in conclusion

country：America/American Japan/Japanese Britain/British 

adult/child/adolescent/old people

Primary school student/middle school student/high school student/university student

people less than 40 years old
people over 50 years old
people between 41 and 50 years old
middle-age people
gym 体育馆/健身房
employee和employers

single-use plastic 一次性塑料
single-use chopsticks 一次性筷子

physical exercise 体育锻炼
number of steps per day 一天的步数
amount of exercise per day 一天的运动量

the reading quantity 阅读量
number - 用于可数的对象+可数名词; amount - 用于不可数对象+集合名词

需求：

个人相关
go out for doing sth 外出做...
enjoy the scenery 欣赏风景
enjoy the view 欣赏风景
relax ourselves 放松自己
relax one's mind 放松大脑
keep healthy 保持健康
physical exercise 锻炼身体
be satisfied with life 对生活满意
improve living standard 提高生活水平  the improvement of residents' living standard
achieve a wider horizon
acquire knowledge
try something new

人与人之间
face-to-face communication 面对面交流
shorten the distance with others 拉近人与人的距离
have a good family relationship 有良好的家庭关系
get high-quality friendships and family relationship 获得高质量的友谊


manufacturing 制造业

五、常考主题素材
1. 出行交通工具travel vehicles
2. 飞机airplane；plane
3. 高铁high-speed rail
4. 自驾汽车self-driving cars
5. 购物人数the number of shoppers
6. 网上购物online shopping
7. 商场购物shopping in the malls
8. 家庭花销 household expenses
9. 日常生活费用daily living expenses
10. 孩子教育费用the costs of child education
11. 医疗费用hospitalization costs； medical expense
12. 学历与就业education and employment
13. 博士doctor
14. 研究生postgraduate
15. 本科 undergraduate
16. 专科junior college students
17. 休闲生活方式leisure life style
18. 短期旅行short-term travel
19. 拜访朋友visiting friends
20. 看电影seeing a movie
21. 在家睡觉sleeping at home
22. 图书市场份额the market share of the books
23. 电子读物e-books
24. 纸质书paper books
25. 毕业生的未来选择the future choice of graduates
26. 自主创业starting a business
27. 公司职员company employees
28. 参加升学考试taking the entrance examination
29. 出国going abroad
30. 计划生育family planning； birth control
31. 人口总数the total population
32. 老人人口the elderly population
33. 追求医疗品质pursuing medical quality
34. 医生从业人数the number of doctors
35. 患者满意度the patient satisfaction
36. 高校学生选修课程the elective courses for college students
37. 人文科学课程humanities courses
38. 自然科学课程natural science courses
39. 经济类课程economics courses
40. 语言类课程language courses
41. 老师授课能力teacher's teaching ability
42. 通过考试难易度the difficulty degree of passing the exam
43. 个人兴趣爱好personal interest
foreign famous universities
domestic Famous University
theater 剧院
movie theater 电影院
number of Masters Admissions
electric car
wear glasses
short sight近视
travel abroad 出国旅游


We should bear in mind that the spirit of 主题词 is of great importance to both our life and study

It is not difficult to draw such conclusion that enough attention must turn to 主题词 by ourselves personally and our community.

   That notwithstanding, what should be our next step? (11) Individually, we must scrupulously evaluate the 
possibility of any adverse conditions initiated by this phenomenon. (12) Government divisions must, on an 
authoritarian level, assign huge significance to arduously guiding people’s behaviors.

