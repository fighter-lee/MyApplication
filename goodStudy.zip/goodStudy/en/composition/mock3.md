![avatar](../pic/mock3.png)
1. the number of students studying abroad
2. the growth rate of students studying abroad
3. achieve a wider horizon
4. acquire knowledge