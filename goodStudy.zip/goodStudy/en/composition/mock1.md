![avatar](../pic/mock1.png)

1. the number of cars owned by Chinese family.
2. travel and commute
3. have a convenient livelihood