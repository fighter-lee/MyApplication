Good morning distinguished professors:
    I am very glad to be here for this interview.
    My name is xxx， twenty-six years old. I come from changsha.
    I've finished my undergraduate education in xiangtan University in year twenty-sixteen and I have been working as a
programmer at an internet company for four years since my graduation. My position is Android Software Engineer in the field
of internet of things and internet of vehicles, the products I participated in have served hundreds of millions of users worldwide.
    In daily life, I like traveling, cooking, and sports，because it keeps me physically and mentally healthy. I love to create
something new, to learn something new. I often study other people's excellent open source works on github.Although I have been
working for four years, and grasp the essential knowledge of the major, but I think at present, I can do many things in a
superficial level,But no ability to solve deep problems owing to lack of ample knowledge and ability. So I think further
study is still urgent for me to realize self-value. Maybe I'm not mature enough. But I am very willing to grow up, to learn,
to fright! I'm aspire to improve my competitiveness.
