hometown相关：
My hometown is changsha,The capital city of Hunan Province, it is a beautiful city.
Surrounding the city are the beautiful Yuelu Mountain,and the Xiangjiang River flow across it.

family相关：
There are four members in my family: My parents, and my grandmother and me.
My parents are typical Chinese farmers. Both of them are diligent and kind.
My grandma is 80 years old and she is in good health.
I love my family.

