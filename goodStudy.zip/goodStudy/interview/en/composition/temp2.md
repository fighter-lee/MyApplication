1. 社会鼓励的中心主题，应该被推广；
2. 健全人格的基础，培养社会责任感；
3. 做事可靠负责的先决条件，不认识这种宝贵的品质就不会取得杰出成就；
4. 动态的过程，引导社会保持文明和谐，证明这一美德的历久弥新；
5. 每个人以具体行动践行孝道，提升整体社会风气的积极因数；

   Practically, what the cartoon intends to convey is that filial piety, as one of the most important central themes that
the society puts emphasis on, deserves to be advocated vigorously. First and foremost, repaying our parents, which acts
as the very foundation of a sound personality, offers a storage power for us to cultivate the sense of responsibility.
Namely, being filial is a prerequisite to engage in dependable conduct and none of outstanding achievement would be made
if we haven't perceived the preciousness of the virtue. Additionally, caring for the old is a active process that leads
the entire society to sustain harmonious and civilized, so as to better demonstrate the vitality of this enduring virtue.
































   Practically, what the cartoon intends to convey is that filial piety, as one of the most important central themes that the society puts
emphasis on, deserves to be advocated. First and foremost, repaying our parents which acts as the very foundation of a sound personality,
offers a storage power for us to cultivate our social responsibility. Namely, filial piety is a prerequisite to engage in dependable conduct
and none of outstanding achievements would be made if we haven't perceived the preciousness of this virtue. Additionally, caring for the old
is a active process that leads the entire society to sustain harmonious and civilized, so as to better demonstrate the vitality of this enduring
virtue.



































   Practically, what the cartoon intends to convey is that filial piety, as one of the most important central themes that
the society puts emphasis on, deserves to be advocated. First and foremost, being filial which acts as the very foundation of
a sound of personality, offers a storage power for us to cultivate the sense of responsibility. Namely, filial piety is a
prerequisite that engage in dependable conduct and none of outstanding achievements would be made if we haven't perceived the
preciousness of this virtue. Additionally, caring for the old is an active process that leads the entire society sustain
harmonious and civilized, so as to demonstrate the vitality of this virtue.





