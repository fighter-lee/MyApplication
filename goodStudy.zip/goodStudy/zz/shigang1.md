![avatar](./pic/新中国成立.png)
1. 两半社会
新民主主义革命取得了基本的胜利，标志了新民主主义社会在全中国建立
帝国主义压迫中国，奴役中国人民的历史从此结束

从根本上改变了中国社会的发展方向，为新民主主义向社会主义过度创造了条件；
基本完成了民族独立和民族解放，为实现国家繁荣富强，人民共同富裕的历史任务创造了前提，中华民族走上了伟大复兴了壮阔道路；

1.新民主主义；
2.帝国主义；
3.社会发展方向，为新民主主义向社会主义过渡；
4.民族独立和民族解放，为实现国家繁荣富强、人民工图富裕创造了前提，从此中华民族走上了伟大复兴的壮阔道路；

![avatar](./pic/中华民族前进的步伐不可阻挡.png)
1.顺应历史；人民群众对美好生活的向往
2.顺应时代；和平发展、合作共赢
3.中华民族及中国共产党的特点；

![avatar](./pic/中华民族伟大复兴的措施.png)
新时期创造中华民族伟大复兴的伟大措施：
1.坚持中共的领导：取得伟大成就，再创辉煌的根本保证；
2.坚持人民主体地位；不断创造新的历史伟业的根本所在；
3.坚持中特主义：当代中国赶上和引领时代发展的康庄大道；

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void click1(View view) {
//        striking/gradual growth/decline;
//        significant/slight decline/growth
//        （） takes th
        //        e percentage of (), ranging for the close/distant second.
        new AlertDialog.Builder(this)
                .setTitle("title")
                .setMessage("message:aaaaaaaa/bbbbbbbb/cccccccccccc")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();

                    }
                })
                .setCancelable(true)
                .create()
                .show();
    }