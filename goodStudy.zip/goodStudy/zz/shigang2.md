![avatar](./pic/五四运动新特点.png)

革命目的--彻底的翻地反封建；
革命力量--有青年知识分子、民族资产阶级、工人阶级广泛参与的人民群众运动；
革命理论--第一次伟大的思想启蒙运动，促进了马克思主义的传播；

彻底翻地反封建的革命性：伟大的爱国革命和伟大的社会革命
各族各界群众参与的广泛性：青年知识分子、民族资产阶级、工人阶级广泛参与的人民群众运动；


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void click1(View view) {
//        striking/gradual growth/decline;
//        significant/slight decline/growth
//        （） takes th
        //        e percentage of (), ranging for the close/distant second.
        new AlertDialog.Builder(this)
                .setTitle("title")
                .setMessage("message:aaaaaaaa/bbbbbbbb/cccccccccccc")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();

                    }
                })
                .setCancelable(true)
                .create()
                .show();
    }